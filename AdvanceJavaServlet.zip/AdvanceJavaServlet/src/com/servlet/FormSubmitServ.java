package com.servlet;

import java.io.IOException;

import java.io.PrintWriter;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import javax.servlet.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class FormSubmitServ extends HttpServlet {
	
	public void service(HttpServletRequest req,HttpServletResponse resp) throws IOException,ServletException {
		
		String st1 = req.getParameter("name");
		String st2 = req.getParameter("email");
		String st3 = req.getParameter("pass");
		
		// 1. Simple
		
//		resp.setContentType("text/html");
//
		PrintWriter pw = resp.getWriter();
//		
//		pw.println("<h3> Name : " + st1 + "</h3>");
//		pw.println("<h3> Email : " + st2 + "</h3>");
//		pw.println("<h3> Password : " + st3 + "</h3>");
		
		// 2 Request Dispatcher
		
//		req.setAttribute("name", st1);
//		req.setAttribute("email", st2);
//		req.setAttribute("pass", st3);
//		
//		RequestDispatcher rd = req.getRequestDispatcher("gfd");
//		rd.forward(req, resp);
		
		// 3. Send Redirect	
		
//		resp.sendRedirect("gfd?name="+st1);
		
		// 4. Using Session
		
//		HttpSession hs = req.getSession();
//		hs.setAttribute("name", st1);
//		hs.setAttribute("email", st2);
//		hs.setAttribute("pass", st3);
//		
//		resp.sendRedirect("gfd");
		
		// 5. Using Cookies
		
//		System.out.println("name : "+st1);
		
//		st1 = st1.replaceAll(" ", "_");
//
//		Cookie ck1 = new Cookie("name", st1);
//		Cookie ck2 = new Cookie("email", st2);
//		Cookie ck3 = new Cookie("pass", st3);
//
//		resp.addCookie(ck1);
//		resp.addCookie(ck2);
//		resp.addCookie(ck3);
//
//		resp.sendRedirect("gfd");
		
		pw.println("Hello");
		
		// 6. Servlet Config
		
//		ServletConfig cg = getServletConfig();
//		String str1 = cg.getInitParameter("name");
		
		// 7. Servlet Context
		
//		ServletContext ctx = req.getServletContext();
//		String str2 = ctx.getInitParameter("name");
//		String str3 = ctx.getInitParameter("phone");
//		
//		pw.println("str1 : " + str1);
//		pw.println("str2 : " + str2);
//		pw.println("str3 : " + str3);
		



		
		
		
	}

}
