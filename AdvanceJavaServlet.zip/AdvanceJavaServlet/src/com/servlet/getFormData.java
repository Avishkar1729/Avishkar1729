package com.servlet;

import java.io.IOException;


import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Cookie;


public class getFormData extends HttpServlet {
	
	
	public void service(HttpServletRequest req,HttpServletResponse resp) throws IOException,ServletException {
		
		resp.setContentType("text/html");

		PrintWriter pw = resp.getWriter();
		
		pw.println("Welcome to form data");
		
		// 2.
		
//		String name = req.getAttribute("name").toString();
//		String email = req.getAttribute("email").toString();
//		String pass = req.getAttribute("pass").toString();

//		pw.println("<h3> Name : " + name + "</h3>");
//		pw.println("<h3> Email : " + email + "</h3>");
//		pw.println("<h3> Password : " + pass + "</h3>");
		
		// 3. Using Redirect
		
//		String name = req.getParameter("name").toString();
//		
//		pw.println("<h3> Name : " + name + "</h3>");
		
		// 4. Using Session 
		
//		HttpSession hs = req.getSession();
//		
//		String name = hs.getAttribute("name").toString();
//		String email = hs.getAttribute("email").toString();
//		String pass = hs.getAttribute("pass").toString();
//
//		pw.println("<h3> Name : " + name + "</h3>");
//		pw.println("<h3> Email : " + email + "</h3>");
//		pw.println("<h3> Password : " + pass + "</h3>");
		
		// 5. Using Cookies

		String name=null,email=null,pass=null;
		Cookie ck[] = req.getCookies();
		
		for(Cookie temp : ck) {
			
			if(temp.getName().equals("name")) {
				name = temp.getValue();
			}
			
			else if(temp.getName().equals("email")) {
				email = temp.getValue();
			}
			
			else if(temp.getName().equals("pass")) {
				pass = temp.getValue();
			}
		}
		
		name = name.replaceAll("_", " ");

		pw.println("<h3> Name : " + name + "</h3>");
		pw.println("<h3> Email : " + email + "</h3>");
		pw.println("<h3> Password : " + pass + "</h3>");
		
		
	}


}
