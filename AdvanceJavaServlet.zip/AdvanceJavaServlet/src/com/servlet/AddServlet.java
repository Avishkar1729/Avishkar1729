package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

// direct method to redirect page without adding code in web.xml
//@WebServlet("/add")
public class AddServlet extends HttpServlet {
	
	public void service(ServletRequest req,ServletResponse resp) throws IOException,ServletException {
		
		int n1 = Integer.parseInt(req.getParameter("num1"));
		int n2 = Integer.parseInt(req.getParameter("num2"));

		int k = n1+n2;
		
		System.out.println(k);
		
		resp.setContentType("text/html");

		PrintWriter pw = resp.getWriter();
		
		pw.println("Addion is : "+k);
		
		pw.println("<h1>Addition is : "+ k + "</h1>");
		
				
		
		
	}

}
