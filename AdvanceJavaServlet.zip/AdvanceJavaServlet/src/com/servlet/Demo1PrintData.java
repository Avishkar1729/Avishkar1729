package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.Cookie;


public class Demo1PrintData extends HttpServlet{

	
	protected void service (HttpServletRequest req, HttpServletResponse resp) throws IOException,ServletException {
	
		PrintWriter pw = resp.getWriter();
		
		//2.
		
//		String email = req.getAttribute("email").toString();
//		String pass = req.getAttribute("pass").toString();
//		
//		pw.println("Email : " + email);
//		pw.println("Password : " + pass);
		
		
		// 3.
		
		String email=null;
		String pass=null;
		
		Cookie ck[] = req.getCookies();
		
		for(Cookie temp : ck) {
			
			if(temp.getName().equals("email") ) {
				email = temp.getValue();
			}
			
			else if(temp.getName().equals("pass")) {
				pass = temp.getValue();
			}
			
		}
		
		pw.println("Email : " + email);
		pw.println("Password : " + pass);
		
		
		

		
	}
}
